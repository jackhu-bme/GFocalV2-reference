import sys
import os
import cv2 as cv
import time
sys.path.insert(0,'/mnt/mmdetection-all')
from mmdet.apis import init_detector, inference_detector, show_result_pyplot
import mmcv
sample_path = '/mnt/data-ractified/all/samples'
image_list = os.listdir(sample_path)
save_picture_dir = '/mnt/mmdetection-all/demo/output-jpg'
save_txt_dir = '/mnt/mmdetection-all/demo/output-txt'
weight_path = '/mnt/mmdetection-all/logs-and-models/faster-rcnn/epoch_8.pth'
config_file_path = '/mnt/mmdetection-all/logs-and-models/faster-rcnn/faster_rcnn_r101_fpn_1x_coco.py'
num2class = ['bz','rbc','wbc','hc','gc','tc','zfq']

model = init_detector(config_file_path, weight_path, device='cuda:0')
n = len(image_list)
time_total = 0
for img in image_list:
    img_path = sample_path+'/'+img
    img_name, ext = img.split('.')
    save_file_path = save_picture_dir +'/'+img
    save_txt_path = save_txt_dir + '/' +img_name+'.txt'
    img_data = cv.imread(img_path)
    t_start = time.perf_counter()
    result = inference_detector(model, img_path)
    t_end = time.perf_counter()
    time_total+=(t_end-t_start)
    print(img+'detected! in %.6f s'%(t_end-t_start))
    class_total = len(result)
    txt_file = open(save_txt_path,'w')
    for i, j in enumerate(result):
        objectname = num2class[i]
        target_num = j.shape[0]
        if target_num!=0:
            for target_index in range(target_num):
                coord = " ".join(str(j[target_index][s]) for s in range(j.shape[1]))+"\n"
                str_write = str(i)+" "+coord
                txt_file.write(str_write)
                x1 = int(j[target_index][0])
                y1 = int(j[target_index][1])
                x2 = int(j[target_index][2])
                y2 = int(j[target_index][3])
                conf = "%.2f" %j[target_index][4]
                text = objectname+conf
                cv.rectangle(img_data, (x1, y1), (x2, y2), (255, 255, 255),thickness=2)
                cv.putText(img_data, text, (x1, y1), cv.FONT_HERSHEY_COMPLEX, 0.7, (108, 96, 244))
    cv.imwrite(save_file_path, img_data)
    txt_file.close()
print("%s pictures finished!"%str(n))
print("total detect time:%.6f s"%time_total)
print("average detect time:%.6f s"%(time_total/n))
        # for target
        # cv.rectangle(img, (x1, y1), (x2, y2), (255, 255, 255), thickness=2)
        #             cv.putText(img, objectname, (x1, y1), cv.FONT_HERSHEY_COMPLEX, 0.7, (0, 255, 0),
        #                     thickness=2)
        #             # cv.imshow('head', img)
        #             cv.imwrite(save_file_path, img)